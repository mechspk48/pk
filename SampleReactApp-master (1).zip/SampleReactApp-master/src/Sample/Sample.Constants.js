
const constants = {
    DISPLAY_VALUE:"DISPLAY_VALUE",
    EDIT_VALUE:"EDIT_VALUE"    
}
export default constants;